//
//  ViewController.m
//  SampleWeather
//
//  Created by Aniket Kumar on 27/02/17.
//  Copyright © 2017 winit. All rights reserved.
//

#import "ViewController.h"
#import "WeatherCustomCell.h"

@interface ViewController ()<CLLocationManagerDelegate,UITableViewDelegate,UITableViewDataSource>
{
    CLLocationManager *locationManager;
    NSMutableArray *arrWeatherDataWeek;
    NSDictionary *dictCity;
}
@end

@implementation ViewController
@synthesize currentLocation;

#pragma mark- View Life Cycle Method
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor= [UIColor colorWithRed:247.0/255.0 green:247.0/255.0 blue:247.0/255.0 alpha:1.0];
    [self designTopTitle];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
        [locationManager requestWhenInUseAuthorization];
//  [locationManager startUpdatingLocation];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [self getWeatherWithLatitude:17.78 withLongitude:78.33];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)designTopTitle
{
    UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 15, self.navigationController.view.frame.size.width, 35)];
    lblTitle.backgroundColor = [UIColor clearColor];
    lblTitle.textColor =  [UIColor colorWithRed:51.0/255.0 green:49.0/255.0 blue:146.0/255.0 alpha:1.0];
    lblTitle.font =[UIFont fontWithName:@"Ubuntu-Regular" size:20];
    lblTitle.textAlignment = NSTextAlignmentCenter;
    lblTitle.text = @"Weather Forecast of 5 Day/3Hour";
    [self.view addSubview:lblTitle];

}

-(void)getWeatherData
{
    //http://samples.openweathermap.org/data/2.5/forecast?lat=35&lon=139&appid=b1b15e88fa797225412429c1c50c122a1
}


#pragma mark- Get Data

// Getting Data based on the given API
-(void)getWeatherWithLatitude:(double)latitude withLongitude:(double)longitude
{
    [self.activity startAnimating];
    self.tblVw.hidden = YES;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://samples.openweathermap.org/data/2.5/forecast?lat=%f&lon=%f&appid=b1b15e88fa797225412429c1c50c122a1",latitude,longitude]];
    
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        // handle response
        if (error == nil) {
            id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            NSDictionary *dict = (NSDictionary *)json;
            dictCity = [dict objectForKey:@"city"];
            arrWeatherDataWeek = [dict objectForKey:@"list"];
            [self performSelectorOnMainThread:@selector(loadDataOnMainThread) withObject:nil waitUntilDone:YES];
        }
    }] resume];
    
}

-(void)loadDataOnMainThread
{
    [self.activity stopAnimating];
    self.tblVw.hidden = NO;
    [self.tblVw reloadData];
}

#pragma mark - Location Manager
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    currentLocation.latitude  = 0.0f;
    currentLocation.longitude = 0.0f;
    self.lattitudeValue = currentLocation.latitude;
    self.longitudeValue = currentLocation.longitude;
    NSLog(@"IN AppDelegate Current Location Not available");
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    NSLog(@"IN AppDelegate OldLocation %f %f", oldLocation.coordinate.latitude, oldLocation.coordinate.longitude);
    NSLog(@"IN AppDelegate NewLocation %f %f", newLocation.coordinate.latitude, newLocation.coordinate.longitude);
    
    currentLocation.latitude=newLocation.coordinate.latitude;
    currentLocation.longitude=newLocation.coordinate.longitude;
    self.lattitudeValue = newLocation.coordinate.latitude;
    self.longitudeValue = newLocation.coordinate.longitude;
    [self getWeatherWithLatitude:self.lattitudeValue withLongitude:self.longitudeValue];
 }


#pragma mark- Table View Delegate and Data Source

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 150;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrWeatherDataWeek.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *strIdentifier = @"WeatherCustomCell";
    WeatherCustomCell *cell = [tableView dequeueReusableCellWithIdentifier:strIdentifier];
    if(cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:strIdentifier owner:self options:nil] objectAtIndex:0];
    }
    cell.backgroundColor= [UIColor colorWithRed:84.0/255.0 green:132.0/255.0 blue:170.0/255.0 alpha:1.0];
    cell.lblCity.text = [NSString stringWithFormat:@"City: %@",[dictCity valueForKey:@"name"]];
    NSDictionary *dictData = [arrWeatherDataWeek objectAtIndex:indexPath.row];
    NSString *myString = [dictData valueForKey:@"dt_txt"];
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSDate *yourDate = [dateFormatter dateFromString:myString];
    dateFormatter.dateFormat = @"dd-MMM-yyyy";
    NSLog(@"%@",[dateFormatter stringFromDate:yourDate]);
    
    
    cell.lblDate.text = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:yourDate]];
    NSDictionary *dictMain = [dictData valueForKey:@"main"];

    float minTempKelvin = [[dictMain valueForKey:@"temp_min"] floatValue];
    float maxTempKelvin = [[dictMain valueForKey:@"temp_max"] floatValue];
    float tempF = [[dictMain valueForKey:@"temp"] floatValue];
    float tempC = tempF - 273.15;
    float minTempCelsius = minTempKelvin - 273.15;
    float maxTempCelsius = maxTempKelvin - 273.15;
    
    cell.layer.borderWidth= 1.0;
    cell.layer.borderColor= [[UIColor lightGrayColor] colorWithAlphaComponent:0.5].CGColor;
    cell.userInteractionEnabled= YES;
    cell.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    cell.layer.shadowOpacity = 0.4f;
    cell.layer.shadowRadius = 1.0f;
    cell.layer.shadowOffset = CGSizeMake(1, -2);
    cell.lblTemp.text = [NSString stringWithFormat:@"Temp: %0.2f°C",tempC];
    cell.lblMinTemp.text = [NSString stringWithFormat:@"Min Temp: %0.2f°C",minTempCelsius];
    cell.lblMaxTemp.text = [NSString stringWithFormat:@"Max Temp: %0.2f°C",maxTempCelsius];
    cell.lblHumidity.text = [NSString stringWithFormat:@"Humidity: %@",[dictMain valueForKey:@"humidity"]];

    NSArray *arrWeather = [dictData valueForKey:@"weather"];
    NSDictionary *dictWeather = [arrWeather objectAtIndex:0];

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^(void) {
        NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://openweathermap.org/img/w/%@.png",[dictWeather valueForKey:@"icon"]]]];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            cell.imgIcon.image = [UIImage imageWithData:imageData];
        });
    });
    return cell;
}


/*
 "main":{
 "temp":283.76,
 "temp_min":283.76,
 "temp_max":283.761,
 "pressure":1017.24,
 "sea_level":1026.83,
 "grnd_level":1017.24,
 "humidity":100,
 "temp_kf":0
 },
 */

/*
 {
 "dt":1485799200,
 "main":{ },
 "weather":[ ],
 "clouds":{ },
 "wind":{ },
 "rain":{ },
 "sys":{ },
 "dt_txt":"2017-01-30 18:00:00"
 },
 */


/*
 "cod":"200",
 "message":0.0082,
 "cnt":40,
 "list":[ ],
 "city":{ }
 */





@end
