//
//  ViewController.h
//  SampleWeather
//
//  Created by Aniket Kumar on 27/02/17.
//  Copyright © 2017 winit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController

@property(nonatomic, assign) CLLocationCoordinate2D currentLocation;
@property (nonatomic,assign) double lattitudeValue;
@property (nonatomic,assign) double longitudeValue;
@property (weak, nonatomic) IBOutlet UITableView *tblVw;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activity;

@end

