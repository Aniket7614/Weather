//
//  WeatherCustomCell.h
//  SampleWeather
//
//  Created by Aniket Kumar on 28/02/17.
//  Copyright © 2017 winit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeatherCustomCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgIcon;
@property (strong, nonatomic) IBOutlet UILabel *lblCity;
@property (strong, nonatomic) IBOutlet UILabel *lblDate;
@property (strong, nonatomic) IBOutlet UILabel *lblHumidity;
@property (strong, nonatomic) IBOutlet UILabel *lblMaxTemp;
@property (strong, nonatomic) IBOutlet UILabel *lblTemp;
@property (strong, nonatomic) IBOutlet UILabel *lblMinTemp;

@end
